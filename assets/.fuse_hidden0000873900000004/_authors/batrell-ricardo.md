---
title: Batrell, Ricardo
---