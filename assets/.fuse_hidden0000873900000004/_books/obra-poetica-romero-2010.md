---
title: "Obra poética"
key: "CAY7UB2X"
author: Romero, Pedro Blas Julio
---
<div data-schema-version="8"><p>En un principio</p> <p>el Sol fue hecho a piedras</p> <p>sobre piedras</p> <p>desde toda la ternura del oscuro vulgo</p> <p>Y ya teníamos el poniente Pedregal</p> <p>que también inventamos</p> <p>con bastones del estilo</p> <p>para golpear</p> <p>levantando el goce</p> <p>Después de aquí</p> <p>al Sol se lo llevaron cuando ya hecho</p> <p>la policía del Creador atravesó furtiva</p> <p>entre Getsemaní y el sueño</p> <p>Ahora nadie se explica</p> <p>el porqué</p> <p>incansable su esfera</p> <p>lo ilumina todo</p> </div>