---
title: "Antología de poetas negros uruguayos"
key: "SF4S3HQQ"
author: Britos Serrat, Alberto
---
<div data-schema-version="6"><p>Encerrémonos en nosotros</p> <p>hermano negro</p> <p>y bebamos nuestro vino,</p> <p>en afán de evadirnos</p> <p>de toda hostilidad.</p> <p>Hermano negro</p> <p>el vino es bueno</p> <p>y para nosotros</p> <p>blasfemar es malo,</p> <p>y as ansias</p> <p>nos enferman de impotencia</p> <p>al quebrarnos</p> <p>en nuestras vidas sin ecos.</p> </div>