---
title: "Looking within: selected poems"
key: "T2MRNEZA"
author: Morejón, Nancy; Cordones-Cook, Juanamaría; Abudu, Gabriel; Frye, David; Abraham Hall, Nancy; Quintanales, Mirta; Sievert, Heather Rosario; Weaver, Kathleen
---
<div data-schema-version="8"><p>Yesterday, she did not understand mathematics</p> <p>but she read with pleasure a history of Africa</p> <p>where they talked about</p> <p>slave trafficking and galleons.</p> <p>Today, he founded a baseball team</p> <p>and he donated blood at the small provincial hospital.</p> <p>She ran a whole course</p> <p>and he went to buy tasty clams</p> <p>at a market.</p> <p>He dreamt about Indian women all doing laundry at the riverbank.</p> <p>She went to the icebox</p> <p>and, with an almost forbidden pleasure,</p> <p>she devoured the clams that he had bought</p> <p>at the market.</p> <p>It is ten past four in the afternoon.</p> <p>Both are looking through the same lens</p> <p>and they have shared the same hope.</p> </div>