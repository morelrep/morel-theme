---
title: "Sirena Selena vestida de pena"
key: "HF7J8EJB"
author: Santos-Febres, Mayra
---
<div data-schema-version="8"><p>El más grande, la más chiquita. Uno hombre, el otro mujer, aunque puede ser el más chico, que no necesariamente sea un hombre el más fuerte ni el más grande que el otro, sino el que dirige, el que decide, el que manda. Hay muchas maneras de mandar, muchas formas de ser hombre o de ser mujer, una decide. A veces se puede ser ambas sin tener que dejar de ser ni lo uno ni lo otro. Dinero, el carrazo, los chavos para irse lejos, para entrar en las barras más bonitas, más llenas de dulces. Eso le toca al hombre. Y si se baila y otro dirige entonces se es la mujer. Y si ella decide adónde va, entonces es el hombre, pero si se queda entre los brazos de Migueles, que dirige, es una mujer. ¿Y si fue ella quien lo convence a bailar, quien lo atrae con su cara caliente y sus trampas? Entonces, ¿quién es el hombre, la mujer?</p> </div>