---
title: "Poemas con botas y banderas"
key: "8EXDA9P9"
author: Artel, Jorge
---
<div data-schema-version="8"><p style="padding-left: 40px" data-indent="1">Poemas</p> <p>escritos con lágrimas</p> <p>de un niño sin pan;</p> <p>con las manos podridas de un soldado</p> <p>que no volvió de la guerra;</p> <p>con el rencor de un negro</p> <p>linchado por las turbas del Sur;</p> <p>con las palabras de un obrero</p> <p>y la angustia de una patria encadenada,</p> <p>cumplid vuestro destino de los hombres:</p> <p>prendidos de sus labios,</p> <p>con el pulso de sus corazones,</p> <p>marcando el ritmo igual y firme de sus pasos,</p> <p>hacia la libertad.</p> </div>