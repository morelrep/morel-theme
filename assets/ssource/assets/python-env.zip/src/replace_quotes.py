import os
os.system("clevercsv standardize --output ../../../_data/books.csv ../../../assets/data/books_zotero.csv")
