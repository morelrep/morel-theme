---
title: de la Torre Córdoba, Jenny
---