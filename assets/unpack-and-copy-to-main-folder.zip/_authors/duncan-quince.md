---
title: Duncan, Quince
---