---
title: Truque, Carlos Arturo
---