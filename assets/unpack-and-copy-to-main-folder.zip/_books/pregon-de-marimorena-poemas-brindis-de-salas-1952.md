---
title: "Pregón de marimorena (poemas)"
author: Brindis de Salas, Virginia
---
<div data-schema-version="8"><p>La hora ciega a los otros</p> <p>que viven del otro lado.</p> <p>Amigo, quítate la venda</p> <p>quítate la venda</p> <p>que a ti te ciega en este,</p> <p>quítate la venda.</p> <p> </p> <p>Es hora de dejar libres</p> <p>pasiones y ocios mentales.</p> <p>Amigo bulle mi sangre</p> <p>mientras la tuya se estanca;</p> <p>quítate la venda, quítate.</p> <p> </p> <p>La hora sangró la tierra,</p> <p>fortalece una simiente;</p> <p>¿qué cosecharán tus manos,</p> <p>tus dos manos bien inertes?</p> </div>