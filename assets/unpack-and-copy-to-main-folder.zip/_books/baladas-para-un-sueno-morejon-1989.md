---
title: "Baladas para un sueño"
author: Morejón, Nancy
---
<div data-schema-version="8"><p>Eres el amo.</p> <p>Azares y un golpe seco de la historia</p> <p>te hicieron ser mi amo.</p> <p>Tienes la tierra todo</p> <p>y yo tengo la pena.</p> <p>En medio de la noche</p> <p>te alzas como una bestia en celo.</p> <p>Tuyos mi sudor y mis manos.</p> <p>Me has hecho nómada en mis propios confines.</p> <p>Eres el amo</p> <p>y eres esclavo</p> <p>de lo que posees.</p> <p>Eres el amo.</p> <p>Me has despojado de mis cosas</p> <p>pero no de mi canto.</p> <p>¿Qué vas a hacer</p> <p>cuando me alce mañana</p> <p>y recobre mi potro, mi olivo</p> <p>y mis estrellas?</p> </div>