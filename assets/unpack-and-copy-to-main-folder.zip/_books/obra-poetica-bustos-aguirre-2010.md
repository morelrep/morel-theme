---
title: "Obra poética"
author: Bustos Aguirre, Rómulo
---
<div data-schema-version="8"><p>Arrastra sus alas de ángel sonámbulo</p> <p>como quien busca una puerta entre largos corredores</p> <p>Triste de sí</p> <p>Pulsando inútil las cuerdas más dulces</p> <p>de mi alma</p> <p>Quizás me existiera desde siempre</p> <p>¿De qué ancho cielo habrá venido este huésped que no conozco?</p> </div>