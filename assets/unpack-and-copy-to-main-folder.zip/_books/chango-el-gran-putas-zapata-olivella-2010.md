---
title: "Changó, el gran putas"
author: Zapata Olivella, Manuel
---
<div data-schema-version="8"><p>Sube a bordo de esta novela como uno de los tantos millones de africanos prisioneros en las naos negreras; y siéntete libre aunque te aten las cadenas.</p> <p>¡Desnúdate!</p> <p>Cualesquiera que sean tu raza, cultura o clase, no olvides que pisas la tierra de América, el Nuevo Mundo, la aurora de la nueva humanidad. Por lo tanto hazte niño. Si encuentras fantasmas extraños —palabra, personaje, trama— tómalos como un desafío a tu imaginación. Olvídate de la academia, de los tiempos verbales, de las fronteras que separan la vida de la muerte, porque en esta saga no hay más huella que la que tú dejes: eres el prisionero, el descubridor, el fundador, el libertador.</p> </div>