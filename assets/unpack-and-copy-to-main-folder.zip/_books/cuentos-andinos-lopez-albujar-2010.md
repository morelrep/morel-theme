---
title: "Cuentos andinos"
author: López Albújar, Enrique
---
<div data-schema-version="8"><p>Se diría que el indio gozaba con esta vida de inquietud y peligro, que su naturaleza fuerte y bravía necesitaba de estas persecuciones violentas, en las que, mientras sus perseguidores desplegaban toda la habilidad de un cazador apasionado, él desplegaba toda la ferocidad del tigre y toda la astucia del zorro. De aquí que la persecución se convirtiese en una especie de duelo a muerte, en el que, más que la vida misma, lo que más se temía perder era el triunfo. Y cada fracaso era un reclamo más para el bandolero, cuya triste celebridad agrandábase hasta circundar su figura de una aureola romántica.</p> </div>