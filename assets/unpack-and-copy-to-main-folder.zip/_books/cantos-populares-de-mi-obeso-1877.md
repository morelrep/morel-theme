---
title: "Cantos populares de mi tierra"
author: Obeso, Candelario
---
<div data-schema-version="6"><p>La noche re una fietas </p> <p>Re Pura i limpia.</p> <p>Caliente taba er baile;</p> <p>Yo retraío,</p> <p>Lleno e la timirece</p> <p>Re un barba-limpio;</p> <p>Maj re repente</p> <p>Vire ciecta picúa</p> <p>Re arto copete.</p> <p>Me enamoré ar momento</p> <p>Re su gacvéza,</p> <p>I junto no soplamos</p> <p>Entre la ruea, </p> <p>A bailá un porro</p> </div>