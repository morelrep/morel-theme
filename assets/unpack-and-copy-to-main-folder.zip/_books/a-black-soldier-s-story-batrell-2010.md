---
title: "A Black Soldier's Story: the Narrative of Ricardo Batrell and the Cuban War of Independence"
author: Batrell, Ricardo; Sanders, Mark A.
---
<div data-schema-version="8"><p>But then I could retreat from the camp, although with sharp pains in my leg. Sanguily, Pedro José Castillo Maróa, his assistant, Pablo Espinosa, and my good friend Leocadio all were able to retreat much faster than I because my wounds hadn’t completely healed. I was a roadblock for me; so I lay down and was now decaying, I was a roadblock for me; so I lay down on the ground next to the tree, and covered myself with dirt; and as it turned out, that saved me.</p> </div>