---
title: "Detrás del rostro"
author: Zapata Olivella, Manuel
---
<div data-schema-version="8"><p>Oía otra voz. No era la suya. Parecía que el doctor Jáuregui le hablaba:</p> <p>—Usted desea dar a Estanislao cuanto ha perdido: padres, hermanos..., un hogar. Ese fingido altruismo le oculta su verdadero deseo: el de tener un hijo nuevo. Así se identifica con su padre. Quiere pagarle el daño inferido al causar la muerte de su madre al nacer. Pero sus pensamientos conscientes son otros. Sustituir al padre de Estanislao, cuando en realidad se gratifica a sí mismo. Dice: "A este niño le han asesinado a sus parientes, le devolveré lo que le han quitado". Brillante oportunidad para descargarse de una antiquísima culpabilidad que lo ultraja desde su infanci</p> </div>