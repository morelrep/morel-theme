---
layout: busquedas
criterio: Date
title: año de edición
tagline: Obras por año de edición
img: tema/edicion.jpg
---