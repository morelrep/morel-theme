---
title: "Nochebuena negra"
key: "DJIXBXIE"
author: Sojo, Juan Pablo
---
<div data-schema-version="8"><p>En la mañana siguiente, mientras las mujeres vaciaban cacao en baba en los alijos que lo bajarían hacia el paso, Crisanto contó a Lino, Emeterio y a cuantos pudieron escucharlo, la noble acción del doctor Goyo... Un indio retaco, fornido, que sacaba filo en el mollejón, escuchaba la historia y sonrió. Lino se fijó en su risa. El indio era algo capachero; tenía pocos días en Pozo Frío y era casi un extraño. Había sido caporal en una hacienda del médico, y él solo sabía de qué se estaba riendo. De la hacienda se vino huido, después de cruzar el Tuy a nado y aparecerse en el rancho de Lino. Se llamaba Guaraco y era hermano de Juana, la mujer de él. Por allí anduvo la “Comisión”, pero en cuatro días no lo hallaron.</p> </div>