---
title: "Always rebellious  (selected poems) = Cimarroneando (poemas escogidos)"
author: Herrera, Georgina; Rodríguez-Alcalá, María; Cordones-Cook, Juanamaría; Cordones Cook, Alexander Michael
---
<div data-schema-version="8"><p>While in the womb</p> <p>of my mother, every</p> <p>now and then, in the midst</p> <p>of the _wemilere_ splendor,</p> <p>the old Oweni spoke</p> <p>through the thick thump thump of the drum.</p> <p>His hoarse voice was heard</p> <p>filled with many longings;</p> <p>claiming,</p> <p>urging his return. Desolated,</p> <p>the fields had become, the grass.</p> <p>How desperate the hunger of the wild beasts!</p> </div>