---
title: "My Mother Was A Freedom Fighter"
key: "8U64UGTM"
author: Monet, Aja
---
<div data-schema-version="8"><p>yesterday i was the toa river</p> <p>where my grandmother rinsed her feet</p> <p>and cupped water into her hands</p> <p>toward her face</p> <p>dripping down her chin</p> <p>along, soft clay bet</p> <p>sculpting a mother </p> <p>A body bathing in daybreak,</p> <p>bleeding beautiful</p> <p>the fish skirt around her calves</p> <p>dragonflies babble on her neck</p> <p>the sun sets her skin ablaze</p> <p>she howls toward the horizon</p> <p>tomorrow</p> <p>tomorrow</p> <p>tomorrow</p> <p>i will be a torch in my daughter</p> </div>