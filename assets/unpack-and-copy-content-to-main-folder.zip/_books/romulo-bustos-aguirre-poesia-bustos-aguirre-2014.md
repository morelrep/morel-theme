---
title: "Rómulo Bustos Aguirre poesía escogida"
key: "FCGD39AV"
author: Bustos Aguirre, Rómulo; Santos García, Emiro
---
<div data-schema-version="8"><p>El mundo es siempre sí y no</p> <p>Sino lúdico. Incongruencia. Humor cósmico</p> <p> Por ejemplo ahora voy a enrollar este texto</p> <p>que aún no es texto</p> <p>Lo voy a enrollar sobre sí mismo</p> <p>Sobre su sí</p> <p>Sobre su no </p> <p>Sobre su sino</p> <p>Sobre su si no</p> <p>Lo voy a enrollar sobre su signo</p> <p>Para que tú</p> <p>lo desenrrolles en su espejeante gnosi(s)</p> </div>