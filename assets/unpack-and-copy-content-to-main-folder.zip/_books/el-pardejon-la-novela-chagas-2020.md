---
title: "El Pardejón: la novela de Fructuoso Rivera"
key: "KBB54Q6Z"
author: Chagas, Jorge
---
<div data-schema-version="8"><p>Así comenzó para mí, Eustaquio Santos, la revolución. Esa revolución que nos dejó marcas para siempre. (Si pudiéramos narrar nuestra historia, una historia de dolores y fatigas, y dijésemos que comenzamos la lucha por el rey de estas tierras que no conocíamos y nunca conoceríamos, ¿nos creerían, acaso? ¿O al oírnos se burlarían de nosotros? ¿Quién pelea por lo que no sabe, por lo que no conoce? Extraña revolución que obligó a cabalgaar juntos a paisanos errantes sin conchabo alguno, chúcaros y retobados, aparceros, curas, infieles, negros y pardos fugados, platudos de nariz respingada y más estirados que perro al sol, con sus pañuelos de seda al cuello y sombreros de ala ancha. Extraña revolución donde ambos ejércitos, patriotas y godos, morían combatiendo en nombre de un mismo rey desconocido.)</p> </div>