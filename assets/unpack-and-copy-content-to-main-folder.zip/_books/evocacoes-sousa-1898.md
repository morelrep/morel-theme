---
title: "Evocações"
key: "HWUHIB4L"
author: Sousa, Cruz e
---
<div data-schema-version="8"><p>N'aquella hora tremenda, grande hora solemne na qual se ia iniciar outra nova vida, foi para mim uma sensibilidade original, um soffrimento nunca sentido, que me desprendia da terra, que me exhilaba do mundo, tal era o choque violento dos meus nervos nesse momento, tal a delicada e curiosa impressão da minh'alma n'esse transe supremo.</p> <p>Ella, abalada por gemidos, na dôr que a dilacerava, quasi desfallecia, com a mais rara expressão raysteriosa nos grandes olhos, os lábios lividos, o semblante de uma contemplatividade de martyrio, transfigurada já pela angustia sagrada d'aquella hora, no instante augusto da Maternidade.</p> </div>