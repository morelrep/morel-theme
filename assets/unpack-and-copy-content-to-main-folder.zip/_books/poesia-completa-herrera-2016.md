---
title: "Poesía completa"
key: "M7Q6UUMH"
author: Herrera, Georgina
---
<div data-schema-version="8"><p>Sobre esos muros</p> <p>Húmedos aún, en las paredes</p> <p>que la lluvia y el llanto de hace tiempo</p> <p>desgastaron e hicieron</p> <p>a la vez eternos, pongo en mis manos.</p> <p>A través de los dedos, oigo</p> <p>gemidos, maldiciones, juramentos</p> <p>de los que, calladamente,</p> <p>resistieron por los siglos</p> <p>los colmillos del látigo en la carne.</p> <p>Todo me llega del pasado, mientras</p> <p>se alza el pensamiento: pido</p> <p>a los sobrevivientes</p> <p>de la interminable travesía</p> <p>fuerza y memoria -- esa</p> <p>devoción por el recuerdo --,</p> <p>y el amor, mucho, todo el amor</p> <p>con que regaron su impetuosa semilla, perpetuándola.</p> <p>Así lo siento, lo recojo.</p> </div>