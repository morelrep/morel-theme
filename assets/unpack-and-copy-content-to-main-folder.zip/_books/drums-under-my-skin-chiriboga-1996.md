---
title: "Drums under my Skin"
key: "CILADSAS"
author: Chiriboga, Luz Argentina; Harris, Mary A.
---
<div data-schema-version="8"><p>My coastal accent caught the attention of women dozing int heir seats, who hid their curiosity by pretending they were arranging packages. At that hour, a general exhaustion induced &nbsp;sleep. I was alone, and imaginary fears crowded my mind. Why had God lost his power to create life and movement at that moment? I heard my mother’s voice again with her “Behave yourself,” which turned into doubts, suspicions, omens, and more precisely, into fears. At te door od the bus station, a man in blue jeans was awaiting the departure of the bus that would take us to Quito. His cap caught my eye, and I could tell from his boots that he had come a long way. I couldn’t see his face as he went up to an etching of an Andean landscape of the wall. It was cold, and so he sank his hands into the pockets of his jacket.</p> </div>