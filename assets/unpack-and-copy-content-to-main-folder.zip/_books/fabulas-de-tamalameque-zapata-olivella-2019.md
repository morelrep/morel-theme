---
title: "Fábulas de Tamalameque"
key: "MPSKQGDA"
author: Zapata Olivella, Manuel
---
<div data-schema-version="8"><p>Tío Elefante en la Aduana Terrestre reclamó:</p> <p>A Tío León que le entregara las garras. </p> <p>A Tío Toro que se arrancara los cuernos. </p> <p>A Tía Culebra que depositara su veneno. </p> <p>A Tío Rinoceronte que le entregara el sable que tenía en su nariz.</p> <p> A Tío Alacrán le pidió su ponzoña. </p> <p>A Tía Gallina le cortó el pico. </p> <p>A Tío Lobo que se sacara los colmillos. </p> <p>A Tía Cebra le quitó los cascos para que no pateara.</p> <p>Y al Hombre, que se presentó desnudo fingiéndose el más manso de los animales, le pidió que dejara la caja de fósforos que llevaba en la mochila para impedirle que usara el fuego, más destructivo que sus mandíbulas y que sus manos.</p> </div>