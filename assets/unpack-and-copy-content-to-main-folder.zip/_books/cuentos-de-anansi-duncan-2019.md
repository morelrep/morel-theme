---
title: "Cuentos de Anansi"
key: "3RA9FP3E"
author: Duncan, Quince
---
<div data-schema-version="8"><p>Los cuentos que usted va a leer, vienen de muy lejos. Los cuenta Jack Mantorra, un viejecito que vino de Jamaica, aquella linda isla del Caribe, y vive en Limón<br>desde hace mucho tiempo. Porque Jack Mantorra es un negrito cuentero, que anda de pueblo en pueblo entreteniendo a la gente con sus extraños personajes.<br>Un gran viejecito cuentero, sí, que pasa el tiempo preocupado por los niños y los jóvenes.</p> <p><br>Jack Mantorra se basa para componer sus cuentos, en las tradiciones que heredó de su abuelito, que era un africano. De ahí vienen algunas de las historias. Otros nombres y otros relatos, vienen del Caribe de donde es el negrito cuentero, como hemos visto. Pero les aseguro que Jack no se queda con tantas cosas del pasado, sino que inventa cuentos para los niños y jóvenes de hoy.</p> </div>