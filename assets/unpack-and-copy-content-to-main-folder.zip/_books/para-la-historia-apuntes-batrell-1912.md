---
title: "Para la historia: apuntes autobiográficos de la vida de Ricardo Batrell Oviedo."
key: "GS6D9RMP"
author: Batrell, Ricardo
---
<div data-schema-version="8"><p>Estuvimos cuatro horas acampados y hacíamos de comer al mismo tiempo, que recibíamos el tesoro más codiciado del sol dado patriota: (municiones), y á más de la que pudiera llevar cada jinete para su necesidad de combatir, se le hizo responsa ble de una caja de mil tiros, á cada uno, sin que pudiera pretextar nadie, que el caballo estaba cansado, porque al que alegaba eso le contestaba la superioridad, que cuando el caballo<br>no pudiera se la echara al hombro.</p> </div>