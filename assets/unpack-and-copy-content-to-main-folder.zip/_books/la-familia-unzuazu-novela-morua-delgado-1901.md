---
title: "La familia Unzúazu: novela cubana"
key: "YWCLA74N"
author: Morúa Delgado, Martín
---
<div data-schema-version="8"><p>Todos en aquella casa habían sido desafectos al señor don Acebaldo Nudoso del Tronco.</p> <p>La que menos fue Magdalena, su cuñada, quien favorecida por su caracter independiente hablale mirado siempre con cierta natural indiferencia. Federico, hermano también de su mujer, detestábale cual descabezado pupil a tutor severo, y afectaba desdeñarle tanto cuanto en realidad le temía. Ana María, la esposa del caballero, había llegado a casi aborrecerle cordialmente, porque le juzgaba indigno de su amor. Y, desde luego, los criados, tal vez los únicos que habrían podido citar agravios justificativos, le odiaban de tal manera que todos intimamente se alegraron de su violenta muerte.</p> </div>