---
title: "No give up, maan! = ¡No te rindas!"
key: "TYDQS6PJ"
author: Robinson Abrahams, Hazel; Chapman, Annie
---
<div data-schema-version="8"><p>—Di lo que quieras, George —intervino Birmington—. Los esclavos del continente han recibido la libertad y aquí también se tocará la campana de la libertad y todo lo demás vendrá con ella.</p> <p>***</p> <p> “Say what you will George,” interrupted Birmington. “Slavery on the mainland has been abolished and it will happen here too. The bell of freedom will toll and everything else will come with it.”</p> </div>