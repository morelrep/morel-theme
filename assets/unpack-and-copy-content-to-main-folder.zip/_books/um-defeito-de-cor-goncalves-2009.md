---
title: "Um defeito de cor"
key: "5W5RQKWK"
author: Gonçalves, Ana Maria
---
<div data-schema-version="8"><p>Passou o resto da noite embalando a filha e o neto mortos, e a luz do dia a encontrou buscando água no rio para molhar e esfregar os dois corpos. Depois cavou o chão no lugar onde dormiam, enrolou cada corpo em uma esteira e os colocou dentro do buraco. Uma única cova rasa para os dois, que mal deu para abrigá-los e à terra que jogou por cima enquanto cantava, para em seguida se ajoelhar ao lado e rezar por horas e horas. No meio da tarde, reacendeu o fogo no quintal e fez comida, que dividiu em cinco partes iguais: uma para mim, uma para a Taiwo, uma para ela e duas para colocar ao lado da cova. Só então desenrolou sua esteira e dormiu, sem ter dito uma única palavra para mim ou para a Taiwo, sem ter chorado uma só lágrima a mais desde a partida dos guerreiros</p> </div>