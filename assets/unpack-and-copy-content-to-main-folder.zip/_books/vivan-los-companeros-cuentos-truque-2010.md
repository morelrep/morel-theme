---
title: "Vivan los compañeros: cuentos completos"
key: "BCJQ65CQ"
author: Truque, Carlos Arturo
---
<div data-schema-version="8"><p>Así, sabroso, regustando el ritmo picante desgranado por los guasás; así, moviéndose en círculos, como sobre un tambor; así, con la sangre corriente, llevándole bien lejos, hacia atrás, a donde ni memoria había.</p> <p>Él allí, dándose su gusto, tirando de los compases como de una cuerda, diablo de negro mandinga, con la boca como brasa del patacoré «que se va caé», se iba sintiendo mejor. Y allá en la tiniebla, la Damiana con su aire y sus pulmones que no daban más, sorbiendo espeso, sacándoles un último lance a las manos para sus dos cununos flácidos, que apenas vibraron un postrer compás antes de quedarse en paz, privaditos, solo simples cueros, sin aire posible ni dolor probable.</p> </div>