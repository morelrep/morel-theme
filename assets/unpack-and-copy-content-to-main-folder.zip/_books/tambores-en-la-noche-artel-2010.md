---
title: "Tambores en la noche"
key: "ID2CMLSS"
author: Artel, Jorge
---
<div data-schema-version="8"><p>Un tono cálido</p> <p>amasado de gritos y de sol.</p> <p>Una estrofa negra,</p> <p>borracha de gaitas vagabundas </p> <p>y golpes dementes de tambor…</p> <p> </p> <p>Un oleaje frenético</p> <p>erizado de calor. Una playa foeteada</p> <p>como espaldas morenas,</p> <p>por las fustas ardientes,</p> <p>y un pedazo de mar —hermano mayor</p> <p>que me enseñó a ser rebelde—</p> <p>me dieron la canción.</p> <p> </p> <p>Se irguió alegre y turbulenta</p> <p>como una jacaranda de jazz band.</p> <p>Colgó de las aspas del faro,</p> <p> —molino de luz—</p> <p> y de las luces del puerto,</p> <p> indecisos cocuyos de tembloroso azul.</p> </div>