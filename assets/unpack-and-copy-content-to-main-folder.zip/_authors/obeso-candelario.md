---
title: Obeso, Candelario
---