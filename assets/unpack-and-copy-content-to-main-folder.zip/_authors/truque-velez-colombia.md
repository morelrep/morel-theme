---
title: Truque Vélez, Colombia
---