---
title: Córdoba, Jenny de la Torre
---